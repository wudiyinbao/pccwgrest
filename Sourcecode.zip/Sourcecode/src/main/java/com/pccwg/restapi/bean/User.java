package com.pccwg.restapi.bean;

import lombok.NoArgsConstructor;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Email;

@NoArgsConstructor
@Data
@Validated
public class User {
	private String id;
	private String first;
	private String last;
	@Email
	private String email;
	private String password;
	private String token;
}
