package com.pccwg.restapi.bean.request;

import lombok.Data;

@Data
public class GetUserRequest {
	private String token;
}
