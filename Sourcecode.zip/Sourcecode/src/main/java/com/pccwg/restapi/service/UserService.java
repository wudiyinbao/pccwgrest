package com.pccwg.restapi.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

import com.pccwg.restapi.bean.User;
import com.pccwg.restapi.bean.request.LoginRequest;
import com.pccwg.restapi.bean.request.NewUserRequest;

import lombok.Synchronized;

@Service
public class UserService {
	private Map<String, User> users = new HashMap<>();
	private Map<String, String> loggedUsers = new HashMap<>();
	
	@Synchronized
    public String addUser(@RequestBody @Valid NewUserRequest userRequest) {
        String id = UUID.randomUUID().toString();
        User user = new User();
        user.setId(id);
        user.setFirst(userRequest.getFirst());
        user.setLast(userRequest.getLast());
        user.setEmail(userRequest.getEmail());
        user.setPassword(userRequest.getPassword());
        users.put(id, user);
        return id;
    }
	
	@Synchronized
    public String login(@RequestBody @Valid LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();
        Set<String> keys = users.keySet();
        User currentUser;
        String token = "";
        for (String key : keys) {
            currentUser = (User)users.get(key);
            if (null != currentUser && currentUser.getEmail().equals(email)
                    && currentUser.getPassword().equals(password)) {
                //token =key.toString() + email.substring(0, email.indexOf("@")).hashCode() + password.hashCode();
                token = email + password;
                loggedUsers.put(token, currentUser.getId());
                return token;
            }
        }
        return token;
    }
	
	@Synchronized
    public String getUserId(String token) {
        if (loggedUsers.containsKey(token)) {
            String id = loggedUsers.get(token);
            return id;
        }
        return null;
    }
	
	@Synchronized
    public User getUser(String token) {
        if (loggedUsers.containsKey(token)) {
            String id = loggedUsers.get(token);
            User user = users.get(id);
            return user;
        }
        return null;
    }

    @Synchronized
    public void logout(String token) {
        if (loggedUsers.containsKey(token)) {
            loggedUsers.remove(token);
        }
    }

}
