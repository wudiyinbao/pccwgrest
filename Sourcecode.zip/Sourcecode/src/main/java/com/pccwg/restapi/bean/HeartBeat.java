package com.pccwg.restapi.bean;

import lombok.NoArgsConstructor;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@NoArgsConstructor
@Data
@Validated
public class HeartBeat {
	private String version;
	private String releasedAt;
}
