package com.pccwg.restapi;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.pccwg.restapi.bean.request.NewUserRequest;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.MediaTypes;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.*;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {UserManagerApplication.class})
public class UserManagerApplicationTest {
	@Rule
    public final JUnitRestDocumentation restDocumentation
            = new JUnitRestDocumentation("target/generated-snippets");

    @Autowired
    private WebApplicationContext context;
    
    @Autowired
    private ObjectMapper objectMapper;
    
	private MockMvc mockMvc;

    @Before
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context)
                .apply(documentationConfiguration(this.restDocumentation))
                .alwaysDo(document("{method-name}", preprocessRequest(prettyPrint()),
                        preprocessResponse(prettyPrint()))).build();
    }

    @Test
    public void createUser() throws Exception {
        Map<String, Object> user = new HashMap<>();
        user.put("first", "Jun");
        user.put("last", "Yu");
        user.put("email", "test1234@qq.com");
        user.put("password", "test1234");

        this.mockMvc.perform(post("/user").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andDo(document("user-create",
            		preprocessRequest(prettyPrint()), preprocessResponse(prettyPrint()), 
            		requestFields(fieldWithPath("first").description("The first name of the user"),
            				fieldWithPath("last").description("The last name of the user"),
                            fieldWithPath("email").description("The email of the user"),
                            fieldWithPath("password").description("The password of the user"))));
    }
    
    @Test
    public void login() throws Exception {
    	 Map<String, Object> user = new HashMap<>();
         user.put("first", "Jun");
         user.put("last", "Yu");
         user.put("email", "test1234@qq.com");
         user.put("password", "test1234");

         this.mockMvc.perform(post("/user").contentType(MediaTypes.HAL_JSON)
             .content(this.objectMapper.writeValueAsString(user)))
             .andExpect(status().isOk()).andReturn();
             
        user = new HashMap<>();
        user.put("email", "test1234@qq.com");
        user.put("password", "test1234");

        this.mockMvc.perform(post("/user/login").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andDo(document("user-login", 
            		preprocessRequest(prettyPrint()), preprocessResponse(prettyPrint()), 
            		requestFields(fieldWithPath("email").description("The token of the user"),
                            fieldWithPath("password").description("The password of the user"))));
    }
    
    @Test
    public void getUser() throws Exception {
    	Map<String, Object> user = new HashMap<>();
        user.put("first", "Jun");
        user.put("last", "Yu");
        user.put("email", "test1234@qq.com");
        user.put("password", "test1234");

        this.mockMvc.perform(post("/user").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andReturn();
        
        user = new HashMap<>();
        user.put("email", "test1234@qq.com");
        user.put("password", "test1234");

        String token = this.mockMvc.perform(post("/user/login").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        System.out.println(token);
        user = new HashMap<>();
        user.put("token", token);
        this.mockMvc.perform(get("/user").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andDo(document("user-get", 
            		preprocessRequest(prettyPrint()), preprocessResponse(prettyPrint()), 
            		requestFields(fieldWithPath("token").description("The token of the user"))));
    }
    
    @Test
    public void logout() throws Exception {
    	Map<String, Object> user = new HashMap<>();
        user.put("first", "Jun");
        user.put("last", "Yu");
        user.put("email", "test1234@qq.com");
        user.put("password", "test1234");

        this.mockMvc.perform(post("/user").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andReturn();
        
        user = new HashMap<>();
        user.put("email", "test1234@qq.com");
        user.put("password", "test1234");

        String token = this.mockMvc.perform(post("/user/login").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        System.out.println(token);
        token = token.substring(token.indexOf(":") + 2, token.length()-2);
        System.out.println(token);
        
        user = new HashMap<>();
        user.put("token", token);
        this.mockMvc.perform(post("/user/logout").contentType(MediaTypes.HAL_JSON)
            .content(this.objectMapper.writeValueAsString(user)))
            .andExpect(status().isOk()).andDo(document("user-logout", 
            		preprocessRequest(prettyPrint()), preprocessResponse(prettyPrint()), 
            		requestFields(fieldWithPath("token").description("The token of the user"))));
    }
    
}
