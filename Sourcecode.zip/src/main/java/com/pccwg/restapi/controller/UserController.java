package com.pccwg.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import com.pccwg.restapi.bean.HeartBeat;
import com.pccwg.restapi.bean.User;
import com.pccwg.restapi.bean.request.GetUserRequest;
import com.pccwg.restapi.bean.request.LoginRequest;
import com.pccwg.restapi.bean.request.LogoutRequest;
import com.pccwg.restapi.bean.request.NewUserRequest;
import com.pccwg.restapi.bean.response.GetUserResponse;
import com.pccwg.restapi.bean.response.LoginResponse;
import com.pccwg.restapi.bean.response.NewUserResponse;
import com.pccwg.restapi.service.UserService;
//import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class UserController {
	
	@Autowired
    private Environment env;
	
	@Autowired
    private UserService userService;
	
	//0. GET /
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public void index(HttpServletResponse response) throws Exception {
        response.sendRedirect("/docs");
    }
	
	//1.GET /heartbeat
	@RequestMapping(value = "/heartbeat", method = RequestMethod.GET)
	public HeartBeat getHeartBeat() {
		HeartBeat hBeat = new HeartBeat();
		hBeat.setVersion(env.getProperty("heartbeat.version"));
		hBeat.setReleasedAt(ZonedDateTime.now(ZoneOffset.UTC).toString());
		return hBeat;
	}

	//2.GET /docs
	@RequestMapping(value = "/docs", method = RequestMethod.GET)
	public void docs(HttpServletResponse response) throws Exception {
		response.sendRedirect("/static/api-guide.html");
	}

	//3.GET /swagger-ui.html
	
	//4.POST /user
	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public NewUserResponse createUser(@RequestBody @Valid NewUserRequest userRequest) throws Exception {
		if(null != userRequest.getEmail() && null != userRequest.getPassword()) {
			LoginRequest loginRequest = new LoginRequest();
			NewUserResponse userResponse = new NewUserResponse();
			
			loginRequest.setEmail(userRequest.getEmail());
			loginRequest.setPassword(userRequest.getPassword());
			String token = userService.login(loginRequest);
			
			if(0 == token.length()) {
				String id = userService.addUser(userRequest);
				userResponse.setId(id);
			}else {
				userResponse.setId(userService.getUserId(token));
				userService.logout(token);
			}
			return userResponse;
		} else {
            throw new Exception("email or password is missing or invalid.");
        }
	}
	
	//5.POST /user/login
	@RequestMapping(value = "/user/login", method = RequestMethod.POST)
	public LoginResponse login(@RequestBody @Valid LoginRequest loginRequest) throws Exception {
		LoginResponse loginResponse = new LoginResponse();
		if(null != loginRequest.getEmail() && null != loginRequest.getPassword()) {
			String token = userService.login(loginRequest);
			if(token.length() > 0) {
				loginResponse.setToken(token);
				return loginResponse;
			} else {
                throw new Exception("email or password is missing or invalid.");
            }
        } else {
            throw new Exception("email or password is missing or invalid.");
        }
	}
	
	//6.GET /user
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public GetUserResponse getUser(@RequestBody @Valid GetUserRequest tokenRequest) throws Exception {
		GetUserResponse userResponse = new GetUserResponse();
		if(null != tokenRequest.getToken()) {
			User user = userService.getUser(tokenRequest.getToken());
			if(null != user) {
				userResponse.setId(user.getId());
				userResponse.setFirst(user.getFirst());
				userResponse.setLast(user.getLast());
				userResponse.setEmail(user.getEmail());
				userResponse.setPassword(user.getPassword());
				
				return userResponse;
			} else {
				throw new Exception("No user found for this token");
			}
		} else {
			throw new Exception("Token is missing or invalid");
		}
	}
	
	//7.POST /user/logout
	@RequestMapping(value = "/user/logout", method = RequestMethod.POST)
	public void logout(@RequestBody @Valid LogoutRequest logoutRequest) throws Exception {
		if(null != logoutRequest.getToken()) {
			User loggedUser = userService.getUser(logoutRequest.getToken());
			if(null != loggedUser) {
				userService.logout(logoutRequest.getToken());
			} else {
                throw new Exception("token is missing or invalid.");
            }
        } else {
            throw new Exception("token is missing or invalid.");
        }
	}
}
