package com.pccwg.restapi.bean.request;

import lombok.Data;

@Data
public class LogoutRequest {
	private String token;
}
