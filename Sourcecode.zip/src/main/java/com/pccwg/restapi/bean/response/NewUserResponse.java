package com.pccwg.restapi.bean.response;

import lombok.Data;

@Data
public class NewUserResponse {
	private String id;
}
