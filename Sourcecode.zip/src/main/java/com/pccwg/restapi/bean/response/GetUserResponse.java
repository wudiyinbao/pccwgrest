package com.pccwg.restapi.bean.response;

import lombok.Data;

@Data
public class GetUserResponse {
	private String id;
	private String first;
	private String last;
	private String email;
	private String password;
}
