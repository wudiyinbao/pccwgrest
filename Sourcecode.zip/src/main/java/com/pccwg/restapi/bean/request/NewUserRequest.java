package com.pccwg.restapi.bean.request;

import lombok.Data;

@Data
public class NewUserRequest {
	private String first;
	private String last;
	private String email;
	private String password;
}
