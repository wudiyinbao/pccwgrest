#1 Use [java -jar pccwgrest.jar] to start the application. Make sure jdk 1.8 is installed in advance.

#2 Use [docker build -t pccwgrest:v1 .] to build a docker image. #(This is tested in docker 18.06.3 on ubuntu in local).

#3 As server.port=8080 set in applicaiton.properties, so use [docker run -p 8080(or else):8080 -t pccwgrest:v1] to run the docker image built in step#2.

#4 Known issues
 Swagger @requestbody POST recieves JSON value as NULL during controller in ApplicatonTest, but it does work by REST client POSTMAN.
 May jackson annotaion work? need to debugger more...

